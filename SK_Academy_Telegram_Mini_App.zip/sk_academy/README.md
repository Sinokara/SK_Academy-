# SK Academy — Mini-app Telegram

Starter fonctionnel en français : catalogue de cours, leçons, quiz, certificats imprimables/PDF et espace administrateur.

## 1. Prérequis
- Node.js 20 ou plus récent.
- Un bot Telegram créé avec **@BotFather**.
- Un hébergement HTTPS public pour la Mini App (ex. Render, Railway ou un serveur personnel).

## 2. Créer le bot avec BotFather
1. Ouvre Telegram et cherche **@BotFather** (compte officiel avec badge de vérification).
2. Envoie `/newbot`, choisis le nom `SK Academy`, puis un identifiant qui se termine par `bot`.
3. BotFather fournit un **token**. Garde-le secret : ne le publie pas, ne le mets pas dans le code du navigateur et ne l'envoie à personne.
4. Configure le nom/description avec `/setdescription` et `/setabouttext` si tu le souhaites.

## 3. Lancer en local
1. Décompresse le projet et ouvre un terminal dans le dossier.
2. Copie `.env.example` vers `.env`, puis remplis `BOT_TOKEN`, `BOT_USERNAME`, `WEBAPP_URL` et `ADMIN_IDS`.
3. Pour un test local seulement, garde `DEV_MODE=true` et lance `npm start` (ou `npm run dev`). Ouvre `http://localhost:3000`.
4. Le mode démo donne accès à l'admin local. Il ne valide pas l'identité Telegram et ne doit JAMAIS être activé en production.

## 4. Déployer en HTTPS
Déploie le dossier sur un hébergeur Node.js qui fournit une URL HTTPS. Ajoute les variables d'environnement dans le tableau de bord de l'hébergeur :
- `BOT_TOKEN` : token donné par BotFather.
- `BOT_USERNAME` : identifiant du bot sans `@`.
- `WEBAPP_URL` : URL HTTPS exacte de l'application.
- `ADMIN_IDS` : ton identifiant numérique Telegram, et ceux des administrateurs autorisés, séparés par des virgules.
- `DEV_MODE=false`.

Redémarre le service. Le serveur répond à `/health` si le déploiement fonctionne.

## 5. Relier le bouton Telegram
1. Dans BotFather, sélectionne ton bot puis utilise `/setmenubutton` (ou l'option **Bot Settings → Menu Button**).
2. Choisis un texte comme `Ouvrir SK Academy` et indique l'URL HTTPS de la Mini App.
3. Le serveur de ce projet répond aussi à `/start` avec un bouton `web_app` qui ouvre la même URL.
4. Si BotFather te demande un domaine Web App, configure le domaine HTTPS de ton hébergement avec la commande proposée par BotFather (`/setdomain`) si elle est disponible dans ton interface.

## 6. Trouver ton identifiant Telegram
Utilise un bot fiable de consultation d'identifiant Telegram, ou ajoute temporairement un mécanisme côté serveur qui lit `user.id` après validation de `initData`. Mets uniquement l'identifiant numérique dans `ADMIN_IDS`. N'utilise pas ton nom d'utilisateur comme identifiant.

## 7. Utiliser l'administration
Ouvre SK Academy depuis Telegram. Si ton ID figure dans `ADMIN_IDS`, l'onglet **Admin** apparaît. Tu peux publier un cours avec ses leçons et une première question de quiz. La bonne réponse est choisie par son numéro (Choix 1, 2, etc.).

## 8. Sécurité et limites de cette version
- Le serveur vérifie la signature cryptographique de `Telegram.WebApp.initData` et sa date avant d'accepter les appels API.
- Les rôles administrateur sont contrôlés côté serveur avec `ADMIN_IDS`.
- Ne partage jamais le token du bot. Si tu l'as exposé, révoque-le avec BotFather (`/revoke`) et remplace la variable.
- Les certificats sont des attestations internes de réussite, imprimables en PDF depuis le navigateur. Ils ne sont pas des diplômes officiels.
- Les données sont enregistrées dans `data.json`. Pour un déploiement multi-instance ou une utilisation à grande échelle, remplace ce stockage simple par une base de données persistante.
- Pour le déploiement réel, utilise un stockage persistant pour `data.json` et configure des sauvegardes.
- Le bot utilise le polling `getUpdates` ; ne configure pas simultanément un webhook sur le même bot.
