const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { URL } = require("node:url");

const PORT = Number(process.env.PORT || 3000);
const BOT_TOKEN = process.env.BOT_TOKEN || "";
const WEBAPP_URL = process.env.WEBAPP_URL || "";
const DEV_MODE = process.env.DEV_MODE === "true" && process.env.NODE_ENV !== "production";
const ADMIN_IDS = new Set((process.env.ADMIN_IDS || "").split(",").map(x => x.trim()).filter(Boolean));
const DB_FILE = path.join(__dirname, "data.json");

const seed = {
  courses: [
    { id: "arabe-1", title: "Les bases de la langue française", description: "Une première leçon pour apprendre à étudier efficacement.", lessons: ["Découvrir les objectifs d’un cours", "Lire et comprendre une leçon", "Réviser avec méthode"], quiz: [{ q: "Quelle action aide à mémoriser une leçon ?", choices: ["Réviser régulièrement", "Ne jamais relire", "Sauter les exercices"], answer: 0 }] },
    { id: "method-1", title: "Méthodes d’apprentissage", description: "Organiser son travail et progresser pas à pas.", lessons: ["Fixer un objectif", "Prendre des notes", "Faire le bilan de ses progrès"], quiz: [{ q: "Quel objectif est le plus utile ?", choices: ["Un objectif précis", "Un objectif impossible", "Aucun objectif"], answer: 0 }] }
  ],
  results: {}
};
function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { fs.writeFileSync(DB_FILE, JSON.stringify(seed, null, 2)); return structuredClone(seed); }
}
let db = loadDB();
function saveDB() { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

function verifyTelegramInitData(initData) {
  if (!BOT_TOKEN || !initData) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;
  params.delete("hash");
  const dataCheckString = [...params.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const calculated = crypto.createHmac("sha256", secret).update(dataCheckString).digest("hex");
  const a = Buffer.from(calculated, "hex"), b = Buffer.from(hash, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || Math.abs(Date.now() / 1000 - authDate) > 86400) return null;
  try { return JSON.parse(params.get("user") || "null"); } catch { return null; }
}
function getUser(req) {
  const initData = req.headers["x-telegram-init-data"] || "";
  const telegramUser = verifyTelegramInitData(initData);
  if (telegramUser?.id) return { id: String(telegramUser.id), first_name: telegramUser.first_name || "Élève" };
  if (DEV_MODE) return { id: "demo-user", first_name: "Élève démo" };
  return null;
}
function send(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(data));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = ""; req.on("data", chunk => { raw += chunk; if (raw.length > 1e6) req.destroy(); });
    req.on("end", () => { try { resolve(JSON.parse(raw || "{}")); } catch (e) { reject(e); } });
    req.on("error", reject);
  });
}
function safeText(v, max=300) { return typeof v === "string" ? v.trim().slice(0, max) : ""; }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method === "GET" && url.pathname === "/health") return send(res, 200, { ok: true, app: "SK Academy" });
  if (req.method.startsWith("GET") && url.pathname.startsWith("/api/")) {
    const user = getUser(req);
    if (!user) return send(res, 401, { error: "Ouvre SK Academy depuis Telegram." });
    if (url.pathname === "/api/bootstrap") {
      const userResults = db.results[user.id] || [];
      return send(res, 200, { user, courses: db.courses.map(c => ({ id:c.id, title:c.title, description:c.description, lessons:c.lessons, quizCount:c.quiz.length })), results: userResults, isAdmin: ADMIN_IDS.has(user.id) || (DEV_MODE && user.id === "demo-user") });
    }
    return send(res, 404, { error: "Route inconnue" });
  }
  if (req.method === "POST" && url.pathname.startsWith("/api/")) {
    const user = getUser(req);
    if (!user) return send(res, 401, { error: "Session Telegram invalide." });
    let body; try { body = await readBody(req); } catch { return send(res, 400, { error: "Données invalides." }); }

    if (url.pathname === "/api/quiz/submit") {
      const course = db.courses.find(c => c.id === body.courseId);
      if (!course) return send(res, 404, { error: "Cours introuvable." });
      const answers = Array.isArray(body.answers) ? body.answers : [];
      const correct = course.quiz.reduce((n, q, i) => n + (Number(answers[i]) === q.answer ? 1 : 0), 0);
      const passed = course.quiz.length > 0 && correct === course.quiz.length;
      const result = { courseId: course.id, courseTitle: course.title, correct, total: course.quiz.length, passed, date: new Date().toISOString(), certificateId: passed ? crypto.randomBytes(5).toString("hex").toUpperCase() : null };
      db.results[user.id] ||= []; db.results[user.id].push(result); saveDB();
      return send(res, 200, result);
    }
    if (url.pathname === "/api/admin/courses") {
      const isAdmin = ADMIN_IDS.has(user.id) || (DEV_MODE && user.id === "demo-user");
      if (!isAdmin) return send(res, 403, { error: "Accès réservé à l’administration." });
      const title = safeText(body.title, 100), description = safeText(body.description, 300);
      const lessons = Array.isArray(body.lessons) ? body.lessons.map(x => safeText(x, 500)).filter(Boolean).slice(0, 30) : [];
      const question = safeText(body.question, 300);
      const choices = Array.isArray(body.choices) ? body.choices.map(x => safeText(x, 150)).filter(Boolean).slice(0, 4) : [];
      const answer = Number(body.answer);
      if (!title || !question || choices.length < 2 || !Number.isInteger(answer) || answer < 0 || answer >= choices.length) return send(res, 400, { error: "Ajoute un titre, une question, au moins deux choix et une bonne réponse valide." });
      const course = { id: crypto.randomUUID(), title, description, lessons, quiz: [{ q: question, choices, answer }] };
      db.courses.push(course); saveDB();
      return send(res, 201, { ok: true, course: { id: course.id, title: course.title } });
    }
    return send(res, 404, { error: "Route inconnue" });
  }

  const requested = url.pathname === "/" ? "/index.html" : url.pathname;
  const file = path.normalize(path.join(__dirname, "public", requested));
  if (!file.startsWith(path.join(__dirname, "public"))) return send(res, 403, { error: "Interdit" });
  fs.readFile(file, (err, content) => {
    if (err) return send(res, 404, { error: "Fichier introuvable" });
    const type = file.endsWith(".css") ? "text/css" : file.endsWith(".js") ? "text/javascript" : "text/html";
    res.writeHead(200, { "Content-Type": `${type}; charset=utf-8` }); res.end(content);
  });
});
server.listen(PORT, () => console.log(`SK Academy démarre sur le port ${PORT}`));

// Bot Telegram : /start et bouton ouvrant la Mini App.
async function telegram(method, payload) {
  if (!BOT_TOKEN) return;
  const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload) });
  if (!r.ok) console.error("Erreur Telegram:", await r.text());
}
async function pollUpdates() {
  if (!BOT_TOKEN) return;
  let offset = 0;
  while (true) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getUpdates?timeout=25&offset=${offset}`);
      const data = await r.json();
      if (data.ok) for (const update of data.result) {
        offset = update.update_id + 1;
        const msg = update.message;
        if (msg?.text === "/start") {
          const keyboard = WEBAPP_URL ? { inline_keyboard: [[{ text:"🎓 Ouvrir SK Academy", web_app:{ url:WEBAPP_URL } }]] } : undefined;
          await telegram("sendMessage", { chat_id:msg.chat.id, text:"Bienvenue sur SK Academy ! Appuie sur le bouton pour accéder aux cours et aux quiz.", reply_markup:keyboard });
        }
      }
    } catch (e) { console.error("Bot Telegram:", e.message); await new Promise(r => setTimeout(r, 3000)); }
  }
}
pollUpdates();