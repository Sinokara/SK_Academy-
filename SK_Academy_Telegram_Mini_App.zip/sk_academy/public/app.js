const tg = window.Telegram?.WebApp;
tg?.ready(); tg?.expand();
const initData = tg?.initData || "";
const headers = { "Content-Type":"application/json", "X-Telegram-Init-Data":initData };
let state = { courses:[], results:[], user:null, isAdmin:false };
const $ = s => document.querySelector(s);
const escapeHtml = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url, options={}) {
  const r = await fetch(url,{...options,headers:{...headers,...options.headers}});
  const data = await r.json(); if(!r.ok) throw new Error(data.error || "Une erreur est survenue."); return data;
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.style.display="block";setTimeout(()=>t.style.display="none",2600)}
function render(){
  $("#greeting").textContent = `Bienvenue${state.user?.first_name ? ", "+state.user.first_name : ""} !`;
  $("#course-count").textContent=state.courses.length;
  $("#passed-count").textContent=state.results.filter(x=>x.passed).length;
  $("#cert-count").textContent=state.results.filter(x=>x.passed).length;
  $("#courses").innerHTML=state.courses.map((c,i)=>`<article class="course"><div class="course-icon">${["📘","🎓","📚","💡"][i%4]}</div><div class="course-info"><h3>${escapeHtml(c.title)}</h3><p>${escapeHtml(c.description||"Formation SK Academy")} · ${c.quizCount} quiz</p></div><button data-course="${escapeHtml(c.id)}">Ouvrir</button></article>`).join("") || '<p class="muted">Aucun cours pour le moment.</p>';
  $("#admin").classList.toggle("hidden",!state.isAdmin); $("#admin-nav").classList.toggle("hidden",!state.isAdmin);
}
function openCourse(id){
  const c=state.courses.find(x=>x.id===id); if(!c)return;
  const dialog=$("#course-dialog"), content=$("#dialog-content");
  content.innerHTML=`<h2>${escapeHtml(c.title)}</h2><p class="muted">${escapeHtml(c.description||"")}</p><h3>Leçons</h3>${(c.lessons||[]).map((l,i)=>`<div class="lesson"><b>Leçon ${i+1}</b><br>${escapeHtml(l)}</div>`).join("")||'<p class="muted">Leçons à venir.</p>'}<h3>Quiz de validation</h3><form id="quiz-form">${(c.quiz||[]).map((q,i)=>`<div class="question">${i+1}. ${escapeHtml(q.q)}</div>${q.choices.map((choice,j)=>`<label class="choice"><input type="radio" name="q${i}" value="${j}" required>${escapeHtml(choice)}</label>`).join("")}`).join("")}<button class="primary" type="submit">Valider mes réponses</button></form><div id="quiz-result"></div>`;
  content.querySelector("#quiz-form").addEventListener("submit",async e=>{
    e.preventDefault();const answers=(c.quiz||[]).map((q,i)=>Number(new FormData(e.target).get("q"+i)));
    try{const result=await api("/api/quiz/submit",{method:"POST",body:JSON.stringify({courseId:id,answers})});state.results.push(result);render();$("#quiz-result").innerHTML=result.passed?`<div class="certificate"><small>SK ACADEMY</small><h3>Certificat de réussite</h3><p>Décerné à <b>${escapeHtml(state.user?.first_name||"l'apprenant")}</b><br>pour la réussite du cours<br><b>${escapeHtml(c.title)}</b></p><small>Référence : ${escapeHtml(result.certificateId)}</small></div><button class="print" id="print-cert">Imprimer / Enregistrer en PDF</button>`:`<p class="notice">Résultat : ${result.correct}/${result.total}. Révise puis réessaie !</p>`;$("#print-cert")?.addEventListener("click",()=>window.print());}catch(err){toast(err.message)}
  });
  dialog.showModal();
}
function showCertificates(){
  const passed=state.results.filter(x=>x.passed);
  $("#course-dialog").showModal();
  $("#dialog-content").innerHTML=`<h2>Mes certificats</h2>${passed.length?passed.map(r=>`<div class="certificate"><small>SK ACADEMY</small><h3>Certificat de réussite</h3><p>Décerné à <b>${escapeHtml(state.user?.first_name||"l'apprenant")}</b><br>pour la réussite du cours<br><b>${escapeHtml(r.courseTitle)}</b></p><small>Référence : ${escapeHtml(r.certificateId)}</small><br><small>${new Date(r.date).toLocaleDateString("fr-FR")}</small></div>`).join(""):'<p class="muted">Tu n’as pas encore de certificat. Réussis un quiz pour en obtenir un.</p>'}<button class="print" onclick="window.print()">Imprimer / Enregistrer en PDF</button>`;
}
$("#courses").addEventListener("click",e=>{const b=e.target.closest("[data-course]");if(b)openCourse(b.dataset.course)});
$("#close-dialog").addEventListener("click",()=>$("#course-dialog").close());
document.querySelectorAll(".bottom button[data-view]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".bottom button").forEach(x=>x.classList.remove("active"));b.classList.add("active");if(b.dataset.view==="certs")showCertificates();if(b.dataset.view==="admin")$("#admin").scrollIntoView({behavior:"smooth"});if(b.dataset.view==="home")window.scrollTo({top:0,behavior:"smooth"})}));
$("#course-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=new FormData(e.target);
  const payload={title:f.get("title"),description:f.get("description"),lessons:String(f.get("lessons")).split("\n").filter(Boolean),question:f.get("question"),choices:String(f.get("choices")).split("\n").filter(Boolean),answer:Number(f.get("answer"))};
  try{await api("/api/admin/courses",{method:"POST",body:JSON.stringify(payload)});$("#admin-message").textContent="Cours publié avec succès.";e.target.reset();await load();}catch(err){$("#admin-message").textContent=err.message}
});
async function load(){try{state=await api("/api/bootstrap");render();}catch(e){$("#courses").innerHTML=`<p class="muted">${escapeHtml(e.message)}<br>Ouvre l’application depuis Telegram après avoir configuré ton bot.</p>`}}
load();